EVEREST LAUNCHER - laptop version (Windows, Mac, Linux)

RUN IT ON A COMPUTER YOU CAN CODE ON
1. Install Node.js 20 or newer from nodejs.org
2. Open a terminal in this folder and run:  npm install
3. Start it with:  npm start
   Press F11 for full screen. Press Esc to go back. Start typing to search apps.

BUILD AN INSTALLER WITH GITHUB (no tools needed)
Upload this project to a new GitHub repo; the Actions tab builds
  Windows: Setup .exe and a portable .exe
  Linux:   .AppImage
  Mac:     .dmg
Download them from the Artifacts section of the finished run.

NOTES
- It lists the programs from your Start Menu (Windows), /Applications (Mac)
  or .desktop files (Linux). Click one to open it.
- "Open at sign-in" in Launcher settings makes it start with your computer.
- 123 3D wallpapers work offline. Photos become 3D; videos play on a curved screen.
