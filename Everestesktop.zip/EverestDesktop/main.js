const { app, BrowserWindow, ipcMain, shell, Menu } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os');
const { spawn } = require('child_process');
let win = null, appsPromise = null;

function walk(d, out, depth = 0) {
  let es = [];
  try { es = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
  for (const e of es) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) { if (depth < 3) walk(p, out, depth + 1); } else out.push(p);
  }
}

async function scan() {
  const items = [];
  if (process.platform === 'win32') {
    const roots = [
      path.join(process.env.ProgramData || 'C:\\ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
      path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs')
    ];
    const files = []; roots.forEach(r => walk(r, files));
    files.filter(f => /\.lnk$/i.test(f)).forEach(f => items.push({ n: path.basename(f, '.lnk'), p: f }));
  } else if (process.platform === 'darwin') {
    ['/Applications', '/System/Applications', '/System/Applications/Utilities', path.join(os.homedir(), 'Applications')].forEach(d => {
      try { fs.readdirSync(d).filter(x => x.endsWith('.app')).forEach(x => items.push({ n: x.slice(0, -4), p: path.join(d, x) })); } catch (e) {}
    });
  } else {
    ['/usr/share/applications', path.join(os.homedir(), '.local/share/applications')].forEach(d => {
      try {
        fs.readdirSync(d).filter(x => x.endsWith('.desktop')).forEach(x => {
          const t = fs.readFileSync(path.join(d, x), 'utf8');
          if (/^NoDisplay=true/m.test(t) || !/^Type=Application/m.test(t)) return;
          const n = (t.match(/^Name=(.+)$/m) || [])[1], ex = (t.match(/^Exec=(.+)$/m) || [])[1];
          if (n && ex) items.push({ n, p: ex.replace(/ ?%[a-zA-Z]/g, '') });
        });
      } catch (e) {}
    });
  }
  const seen = new Set();
  const uniq = items.filter(i => {
    const k = i.n.toLowerCase();
    if (seen.has(k) || /uninstall|readme|license|release notes/i.test(i.n)) return false;
    seen.add(k); return true;
  }).sort((a, b) => a.n.localeCompare(b.n));
  const DOCK = /chrome|edge|firefox|brave|explorer|terminal|safari|files|code|settings/i;
  let dk = 0;
  uniq.forEach(it => { it.d = DOCK.test(it.n) && dk < 4 ? (dk++, true) : false; it.i = ''; });
  if (process.platform !== 'linux') {
    for (let k = 0; k < uniq.length; k += 12) {
      await Promise.all(uniq.slice(k, k + 12).map(async it => {
        try { const img = await app.getFileIcon(it.p, { size: 'large' }); it.i = img.resize({ width: 96, height: 96 }).toDataURL(); } catch (e) {}
      }));
    }
  }
  return uniq.map(it => ({ n: it.n, p: it.p, d: it.d, i: it.i }));
}

ipcMain.on('apps', async (e) => {
  try { e.returnValue = JSON.stringify(await appsPromise); } catch (err) { e.returnValue = '[]'; }
});
ipcMain.on('launch', (e, p) => {
  try {
    if (process.platform === 'linux') {
      const parts = p.match(/"[^"]*"|\S+/g) || [];
      if (!parts.length) return;
      spawn(parts[0].replace(/"/g, ''), parts.slice(1).map(x => x.replace(/"/g, '')), { detached: true, stdio: 'ignore' }).unref();
    } else shell.openPath(p);
  } catch (err) {}
});
ipcMain.on('isStartup', (e) => { e.returnValue = app.getLoginItemSettings().openAtLogin; });
ipcMain.on('toggleStartup', (e) => {
  const on = !app.getLoginItemSettings().openAtLogin;
  app.setLoginItemSettings({ openAtLogin: on });
  e.returnValue = on;
});

function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1280, height: 800, show: false, backgroundColor: '#000000', title: 'Everest Launcher',
    icon: path.join(__dirname, 'build', 'icon.png'), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, autoplayPolicy: 'no-user-gesture-required' }
  });
  win.once('ready-to-show', () => win.show());
  win.webContents.on('before-input-event', (ev, i) => {
    if (i.type === 'keyDown' && i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); ev.preventDefault(); }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => { appsPromise = scan(); createWindow(); });
  app.on('window-all-closed', () => app.quit());
}
