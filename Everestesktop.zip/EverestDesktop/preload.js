const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('EVEREST_DESKTOP', true);
contextBridge.exposeInMainWorld('Android', {
  getApps: () => ipcRenderer.sendSync('apps'),
  launch: (p) => ipcRenderer.send('launch', p),
  isDefault: () => ipcRenderer.sendSync('isStartup'),
  setDefault: () => { ipcRenderer.sendSync('toggleStartup'); }
});
