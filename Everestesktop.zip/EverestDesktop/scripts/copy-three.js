const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..', 'node_modules', 'three', 'build', 'three.min.js');
const dst = path.join(__dirname, '..', 'renderer', 'three.min.js');
fs.copyFileSync(src, dst);
console.log('three.js copied into renderer/');
